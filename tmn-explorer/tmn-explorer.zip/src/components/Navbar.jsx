import React, {useState, useEffect} from 'react';
import { Menu, Input } from 'antd';
import { Link } from 'react-router-dom';
import { HomeOutlined, MoneyCollectOutlined, BulbOutlined  } from '@ant-design/icons';



import icon from '../images/tmp-logo.png';

const Navbar = () => {
  const { Search } = Input;
  const onSearch = value => { console.log(value) }


  return (
     <>
        <div className="logo"><img src={icon}/></div>
        <Menu theme="dark" mode="horizontal">
            <Menu.Item icon={<HomeOutlined/>}>
              <Link to="/">Home</Link>
            </Menu.Item>
            <Menu.Item icon={<MoneyCollectOutlined/>}>
              <Link to="/companies">Companies A-Z</Link>
            </Menu.Item>
            <Menu.Item icon={<BulbOutlined/>}>
              <Link to="/products">Products A-Z</Link>
            </Menu.Item>                
            <Menu.Item icon={<BulbOutlined/>}>
              <Link to="/content">Content A-Z</Link>
            </Menu.Item>
            <Menu.Item>
              <Search
              placeholder="search by company name, product, or generic name"
              allowClear
              enterButton="Search"
              size="large"
              onSearch={onSearch}
            />
            </Menu.Item>
            {/* <Menu.Item icon={<SmileOutlined/>}>
              <Link onClick={() => authenticate({ signingMessage: "Hello World!" })}>Login</Link>
            </Menu.Item>  
            <Menu.Item icon={<SmileOutlined/>}>
              <Link onClick={() => logout()}>Logout</Link>
            </Menu.Item>          */}
        </Menu>
      {/* <div>
        <h1>Welcome {user.get("username")}</h1>
        <button onClick={() => logout()}>Logout</button>
      </div> */}
      
      </>
  )
}

export default Navbar
